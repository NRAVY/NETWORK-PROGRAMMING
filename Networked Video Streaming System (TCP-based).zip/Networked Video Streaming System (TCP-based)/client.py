import socket
import cv2
import pickle
import threading
import time
import argparse
import pyaudio
import queue
import sys
import struct
import numpy as np

# Audio Configuration (must match server)
AUDIO_CONFIG = {
    'format': pyaudio.paInt16,
    'channels': 1,
    'rate': 44100,
    'chunk': 1024
}

class VideoConferenceClient:
    def _init_(self, server_host, server_port=5566, name="Participant"):
        self.server_host = server_host
        self.server_port = server_port
        self.name = name
        self.running = False
        self.streaming = False
        self.start_time = 0
        
        # Network
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.settimeout(5)
        
        # Audio
        self.audio = pyaudio.PyAudio()
        self.audio_config = AUDIO_CONFIG
        self.audio_stream_out = None
        self.audio_stream_in = None
        self.audio_queue = queue.Queue(maxsize=50)
        
        # Video
        self.cap = None
        self.current_video = None
        self.video_playing = False
        self.frame_quality = 80

    def _send_message(self, message):
        try:
            data = pickle.dumps(message)
            self.socket.sendall(struct.pack('!I', len(data)) + data)
            return True
        except Exception as e:
            print(f"Send error: {e}")
            return False

    def _receive_message(self):
        try:
            # Get message length
            header = self.socket.recv(4)
            if not header:
                return None
            msg_len = struct.unpack('!I', header)[0]
            
            # Get message data
            data = b''
            while len(data) < msg_len:
                packet = self.socket.recv(msg_len - len(data))
                if not packet:
                    return None
                data += packet
            return pickle.loads(data)
        except Exception as e:
            print(f"Receive error: {e}")
            return None

    def start(self):
        try:
            print(f"Connecting to {self.server_host}:{self.server_port}...")
            self.socket.connect((self.server_host, self.server_port))
            self.running = True
            
            # Get config from server
            config = self._receive_message()
            if not config or config[0] != 'config':
                raise ConnectionError("Invalid config from server")
                
            self.audio_config = config[1]['audio']
            self.frame_quality = config[1]['video']['quality']
            
            # Setup audio streams
            self.audio_stream_out = self.audio.open(
                format=self.audio_config['format'],
                channels=self.audio_config['channels'],
                rate=self.audio_config['rate'],
                output=True,
                frames_per_buffer=self.audio_config['chunk']
            )
            self.audio_stream_in = self.audio.open(
                format=self.audio_config['format'],
                channels=self.audio_config['channels'],
                rate=self.audio_config['rate'],
                input=True,
                frames_per_buffer=self.audio_config['chunk']
            )
            
            # Setup video capture
            self.cap = cv2.VideoCapture(0)
            if not self.cap.isOpened():
                raise RuntimeError("Camera not available")
                
            print(f"\n🎥 {self.name} connected")
            print("Press ESC to exit")
            
            # Signal ready to server
            self._send_message('READY')
            
            # Start all threads
            threading.Thread(target=self.receive_loop, daemon=True).start()
            threading.Thread(target=self.video_loop, daemon=True).start()
            threading.Thread(target=self.audio_capture_loop, daemon=True).start()
            threading.Thread(target=self.audio_playback_loop, daemon=True).start()
            threading.Thread(target=self.display_loop, daemon=True).start()
            
            while self.running:
                time.sleep(0.1)
                
        except Exception as e:
            print(f"\nError: {e}")
            self.stop()
            sys.exit(1)

    def receive_loop(self):
        while self.running:
            try:
                message = self._receive_message()
                if not message:
                    continue
                    
                if isinstance(message, tuple):
                    msg_type, content = message
                    if msg_type == 'start':
                        self.handle_start(content)
                    elif msg_type == 'video_info':
                        self.handle_video_info(content)
                    elif msg_type == 'audio_frame':
                        self.audio_queue.put(content)  # Add to playback queue
                    elif msg_type == 'error':
                        print(f"\nServer error: {content}")
                        self.running = False
                elif message == 'HEARTBEAT':
                    self._send_message('HEARTBEAT_ACK')
                    
            except Exception as e:
                print(f"Receive loop error: {e}")
                break

    def audio_capture_loop(self):
        """Capture audio from microphone and send to server"""
        while self.running and self.streaming and self.audio_stream_in:
            try:
                audio_data = self.audio_stream_in.read(
                    self.audio_config['chunk'],
                    exception_on_overflow=False
                )
                self._send_message(('audio_frame', audio_data))
            except Exception as e:
                print(f"Audio send error: {e}")
                break

    def audio_playback_loop(self):
        """Play received audio from server"""
        while self.running and self.audio_stream_out:
            try:
                audio_data = self.audio_queue.get(timeout=0.1)
                self.audio_stream_out.write(audio_data)
            except queue.Empty:
                continue
            except Exception as e:
                print(f"Audio playback error: {e}")
                break

    def handle_start(self, start_time):
        self.start_time = start_time
        delay = max(0, self.start_time - time.time())
        print(f"\n⏱ Starting in {delay:.1f} seconds...")
        time.sleep(delay)
        self.streaming = True
        print("🎬 Streaming started!")

    def handle_video_info(self, info):
        self.current_video = info.get('filename')
        self.video_playing = info.get('playing', False)
        self.frame_quality = info.get('quality', self.frame_quality)
        status = "▶ Playing" if self.video_playing else "⏸ Stopped"
        print(f"\n📹 Server Video: {status} {self.current_video or ''}")

    def video_loop(self):
        while self.running and self.cap.isOpened():
            if not self.streaming:
                time.sleep(0.1)
                continue
                
            ret, frame = self.cap.read()
            if not ret:
                print("⚠ Camera error")
                break
                
            # Show local preview
            cv2.imshow(f"{self.name} (You)", frame)
            
            if not self.video_playing:
                try:
                    # Resize and encode frame
                    frame = cv2.resize(frame, (640, 480))
                    encode_params = [int(cv2.IMWRITE_JPEG_QUALITY), self.frame_quality]
                    _, buffer = cv2.imencode(".jpg", frame, encode_params)
                    self._send_message(('video_frame', buffer.tobytes()))
                except Exception as e:
                    print(f"Video send error: {e}")
                    break
                
            if cv2.waitKey(1) & 0xFF == 27:  # ESC key
                self.running = False

    def display_loop(self):
        while self.running:
            try:
                # Check for video frames from server
                header = self.socket.recv(4, socket.MSG_PEEK)
                if header and len(header) == 4:
                    frame_size = struct.unpack('!I', header)[0]
                    if frame_size > 0:
                        # Get the full frame
                        self.socket.recv(4)  # Remove header from buffer
                        frame_data = self.socket.recv(frame_size)
                        
                        # Decode and display
                        frame = cv2.imdecode(
                            np.frombuffer(frame_data, dtype=np.uint8), 
                            cv2.IMREAD_COLOR
                        )
                        if frame is not None:
                            cv2.imshow("Server Video", frame)
                            
                if cv2.waitKey(1) & 0xFF == 27:
                    self.running = False
                    
            except BlockingIOError:
                time.sleep(0.01)
                continue
            except Exception as e:
                print(f"Display error: {e}")
                break

    def stop(self):
        """Clean up all resources"""
        self.running = False
        
        # Camera
        if hasattr(self, 'cap') and self.cap:
            self.cap.release()
            
        # Audio
        if hasattr(self, 'audio_stream_in') and self.audio_stream_in:
            try:
                self.audio_stream_in.stop_stream()
                self.audio_stream_in.close()
            except:
                pass
            
        if hasattr(self, 'audio_stream_out') and self.audio_stream_out:
            try:
                self.audio_stream_out.stop_stream()
                self.audio_stream_out.close()
            except:
                pass
            
        if hasattr(self, 'audio') and self.audio:
            try:
                self.audio.terminate()
            except:
                pass
                
        # Network
        if hasattr(self, 'socket') and self.socket:
            try:
                self.socket.close()
            except:
                pass
                
        cv2.destroyAllWindows()
        print(f"🛑 {self.name} disconnected")

if _name_ == "_main_":
    parser = argparse.ArgumentParser()
    parser.add_argument("host", help="Server IP address")
    parser.add_argument("-p", "--port", type=int, default=5566, help="Server port")
    parser.add_argument("-n", "--name", required=True, help="Your display name")
    args = parser.parse_args()
    
    client = VideoConferenceClient(args.host, server_port=args.port, name=args.name)
    try:
        client.start()
    except KeyboardInterrupt:
        client.stop()
    except Exception as e:
        print(f"Fatal error: {e}")
        client.stop()
        sys.exit(1)