import os
import socket
import pickle
import threading
import time
import pyaudio
import cv2
import numpy as np
from collections import defaultdict
import argparse
import logging
from flask import Flask, render_template, Response, request
import struct
import sys
import io
import select

# Configure system encoding
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# Constants
MAX_FRAME_SIZE = 2 * 1024 * 1024
MAX_MESSAGE_SIZE = 10 * 1024 * 1024
HEARTBEAT_INTERVAL = 5  # Reduced from 10
CLIENT_TIMEOUT = 30
DEFAULT_FRAME_QUALITY = 80
DEFAULT_FRAME_SIZE = (640, 480)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('server.log', encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)

app = Flask(__name__)

class EnhancedStreamServer:
    def __init__(self, host='0.0.0.0', port=5566, min_clients=1, max_clients=4):
        self.host = host
        self.port = port
        self.min_clients = min_clients
        self.max_clients = max_clients
        self.clients = set()
        self.client_socks = {}
        self.ready_flags = defaultdict(bool)
        self.running = False
        self.streaming = False
        self.lock = threading.Lock()
        
        # Audio setup
        self.pyaudio = pyaudio.PyAudio()
        self.audio_config = {
            'format': pyaudio.paInt16,
            'channels': 1,
            'rate': 44100,
            'chunk': 1024
        }
        
        # Video setup
        self.current_video = None
        self.video_playing = False
        self.video_thread = None
        self.video_dir = "videos"
        self.frame_quality = DEFAULT_FRAME_QUALITY
        os.makedirs(self.video_dir, exist_ok=True)
        
        # Web UI
        self.ui_frame = None
        self.ui_lock = threading.Lock()
        
        # Enhanced socket configuration
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 30)
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 5)  # Reduced
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.sock.bind((self.host, self.port))
        self.sock.listen(5)
        self.sock.settimeout(5)  # Reduced from 10

    def start_flask(self):
        """Start the Flask web server"""
        app.run(host=self.host, port=5000, threaded=True)

    def start(self):
        self.running = True
        flask_thread = threading.Thread(target=self.start_flask, daemon=True)
        flask_thread.start()
        
        logger.info(f"\n🎬 Hybrid Streaming Server 🎬")
        logger.info(f"📍 TCP Host: {self.host}:{self.port}")
        logger.info(f"🌐 Web UI: http://{self.host}:5000")
        logger.info(f"👥 Clients: {self.min_clients}-{self.max_clients}")
        logger.info("🛑 Press Ctrl+C to stop")
        
        threading.Thread(target=self.accept_connections, daemon=True).start()
        threading.Thread(target=self.command_handler, daemon=True).start()

        try:
            while self.running:
                time.sleep(0.1)
        except KeyboardInterrupt:
            self.stop()

    def _send_message(self, conn, message):
        """Enhanced message sending with error handling"""
        try:
            data = pickle.dumps(message)
            if len(data) > MAX_MESSAGE_SIZE:
                logger.warning(f"Message too large: {len(data)} bytes")
                return False
            conn.sendall(struct.pack('!I', len(data)) + data)
            return True
        except Exception as e:
            logger.error(f"Send error: {e}")
            return False

    def accept_connections(self):
        """Accept incoming client connections"""
        while self.running:
            try:
                conn, addr = self.sock.accept()
                conn.settimeout(HEARTBEAT_INTERVAL)
                
                with self.lock:
                    if len(self.clients) >= self.max_clients:
                        self._send_message(conn, ('error', 'Server full'))
                        conn.close()
                        continue
                        
                    self.clients.add(addr)
                    self.client_socks[addr] = conn
                    logger.info(f"🎉 {addr} connected ({len(self.clients)}/{self.min_clients})")
                    
                    # Send config
                    self._send_message(conn, ('config', {
                        'audio': self.audio_config,
                        'video': {
                            'quality': self.frame_quality,
                            'max_size': MAX_FRAME_SIZE
                        }
                    }))
                
                threading.Thread(
                    target=self.handle_client,
                    args=(conn, addr),
                    daemon=True
                ).start()
                
            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    logger.error(f"Connection error: {e}")

    def handle_client(self, conn, addr):
        """Enhanced client handler with heartbeat"""
        buffer = b''
        last_active = time.time()
        
        try:
            while self.running:
                try:
                    # Set shorter timeout for recv
                    conn.settimeout(5)
                    
                    # Receive data with size limit
                    data = conn.recv(4096)
                    if not data:
                        break
                        
                    last_active = time.time()
                    buffer += data
                    
                    while len(buffer) >= 4:
                        msg_len = struct.unpack('!I', buffer[:4])[0]
                        if msg_len > MAX_MESSAGE_SIZE:
                            logger.error(f"Client {addr} sent oversized message")
                            break
                            
                        if len(buffer) < 4 + msg_len:
                            break
                            
                        msg_data = buffer[4:4+msg_len]
                        buffer = buffer[4+msg_len:]
                        
                        try:
                            message = pickle.loads(msg_data)
                            if message == 'READY':
                                with self.lock:
                                    self.ready_flags[addr] = True
                                    ready = sum(self.ready_flags.values())
                                    logger.info(f"✅ {addr} ready ({ready}/{self.min_clients})")
                                self.check_start()
                            elif message == 'HEARTBEAT_ACK':
                                continue
                                
                        except Exception as e:
                            logger.error(f"Message error from {addr}: {e}")
                            continue
                            
                    # Send heartbeat every 5 seconds
                    if time.time() - last_active > 5:
                        try:
                            self._send_message(conn, 'HEARTBEAT')
                        except:
                            break
                            
                except socket.timeout:
                    if time.time() - last_active > CLIENT_TIMEOUT:
                        logger.warning(f"Client {addr} timeout")
                        break
                    continue
                except Exception as e:
                    logger.error(f"Client {addr} error: {e}")
                    break
                    
        finally:
            self.remove_client(addr)

    def check_start(self):
        """Start streaming when enough clients are ready"""
        with self.lock:
            ready = sum(self.ready_flags.values())
            if ready >= self.min_clients and not self.streaming:
                self.streaming = True
                start_time = time.time() + 3  # 3 second countdown
                logger.info(f"\n🚀 Starting stream at {time.ctime(start_time)}")
                
                for addr in list(self.client_socks.keys()):
                    try:
                        self._send_message(self.client_socks[addr], ('start', start_time))
                    except:
                        self.remove_client(addr)

    def play_video_file(self, video_path):
        """Start streaming a video file"""
        if not os.path.exists(video_path):
            logger.error(f"File not found: {video_path}")
            return
            
        self.stop_video()
        self.current_video = video_path
        self.video_playing = True
        
        logger.info(f"\n🎥 Playing {os.path.basename(video_path)}")
        
        self.video_thread = threading.Thread(
            target=self.stream_video_file,
            daemon=True
        )
        self.video_thread.start()
        
        with self.lock:
            for addr in self.client_socks:
                self.send_video_info(addr)

    def stream_video_file(self):
        """Enhanced video streaming with keepalive check"""
        cap = cv2.VideoCapture(self.current_video)
        frame_count = 0
        
        while self.video_playing and self.running:
            ret, frame = cap.read()
            if not ret:
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                continue
                
            frame = cv2.resize(frame, DEFAULT_FRAME_SIZE)
            
            # Encode frame
            encode_params = [cv2.IMWRITE_JPEG_QUALITY, self.frame_quality]
            _, buffer = cv2.imencode('.jpg', frame, encode_params)
            frame_data = buffer.tobytes()
            
            # Send to all active clients
            with self.lock:
                active_clients = list(self.client_socks.items())
                
            for addr, conn in active_clients:
                try:
                    # Check if connection is still alive
                    conn.settimeout(1)
                    ready = select.select([], [conn], [], 0)
                    if ready[1]:  # Socket is writable (connected)
                        header = struct.pack('!I', len(frame_data))
                        conn.sendall(header + frame_data)
                        frame_count += 1
                except:
                    self.remove_client(addr)
                    
            time.sleep(0.033)  # ~30fps
            
        cap.release()
        logger.info(f"Stopped video after sending {frame_count} frames")

    def stop_video(self):
        """Stop video playback"""
        if self.video_playing:
            self.video_playing = False
            if self.video_thread and self.video_thread.is_alive():
                self.video_thread.join()
            logger.info("\n⏹ Stopped video playback")
            
            with self.lock:
                for addr in self.client_socks:
                    self.send_video_info(addr)

    def send_video_info(self, addr):
        """Send video status to client"""
        try:
            message = ('video_info', {
                'filename': os.path.basename(self.current_video) if self.current_video else None,
                'playing': self.video_playing,
                'quality': self.frame_quality
            })
            self._send_message(self.client_socks[addr], message)
        except:
            self.remove_client(addr)

    def list_video_files(self):
        """List available videos"""
        logger.info("\n📂 Available videos:")
        videos = [f for f in os.listdir(self.video_dir) 
                 if f.lower().endswith(('.mp4', '.avi', '.mov', '.mkv', '.flv'))]
        
        if not videos:
            logger.info("No videos found")
            return
            
        for i, video in enumerate(videos, 1):
            logger.info(f"{i}. {video}")

    def command_handler(self):
        """Handle server console commands"""
        while self.running:
            try:
                cmd = input("\nServer Command >>> ").strip().lower()
                
                if cmd.startswith("play "):
                    video_file = cmd[5:].strip()
                    video_path = os.path.join(self.video_dir, video_file)
                    self.play_video_file(video_path)
                elif cmd == "stop":
                    self.stop_video()
                elif cmd == "list":
                    self.list_video_files()
                elif cmd == "quality":
                    new_quality = input("Enter new quality (1-100): ")
                    try:
                        self.frame_quality = max(1, min(100, int(new_quality)))
                        logger.info(f"Quality set to {self.frame_quality}")
                    except ValueError:
                        logger.error("Invalid quality value")
                elif cmd == "help":
                    self.show_help()
                else:
                    logger.error("Unknown command. Type 'help' for options.")
                    
            except Exception as e:
                logger.error(f"Command error: {e}")

    def show_help(self):
        """Show available commands"""
        help_text = """
Available commands:
play <filename> - Stream video file
stop            - Stop playback
list            - List available videos
quality         - Change video quality (1-100)
help            - Show this help
"""
        print(help_text)

    def remove_client(self, addr):
        """Remove disconnected client"""
        with self.lock:
            if addr in self.clients:
                self.clients.remove(addr)
            if addr in self.client_socks:
                try:
                    self.client_socks[addr].close()
                except:
                    pass
                del self.client_socks[addr]
            if addr in self.ready_flags:
                del self.ready_flags[addr]
            logger.info(f"👋 {addr} disconnected")

    def stop(self):
        """Cleanup and stop server"""
        self.running = False
        self.stop_video()
        with self.lock:
            for sock in self.client_socks.values():
                try:
                    sock.close()
                except:
                    pass
            try:
                self.sock.close()
            except:
                pass
        self.pyaudio.terminate()
        cv2.destroyAllWindows()
        logger.info("\n🛑 Server stopped")

# Flask routes
@app.route('/')
def index():
    return render_template('index.html', 
                         host=socket.gethostname(),
                         port=server.port)

@app.route('/video_feed')
def video_feed():
    def generate():
        while server.running:
            with server.ui_lock:
                if server.ui_frame:
                    yield (b'--frame\r\n'
                          b'Content-Type: image/jpeg\r\n\r\n' + 
                          server.ui_frame + b'\r\n')
            time.sleep(0.03)
    return Response(generate(), 
                   mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/control')
def control():
    cmd = request.args.get('cmd')
    if cmd == 'play' and server.current_video:
        server.play_video_file(server.current_video)
    elif cmd == 'stop':
        server.stop_video()
    elif cmd == 'quality':
        new_quality = request.args.get('value')
        try:
            server.frame_quality = max(1, min(100, int(new_quality)))
            return f"Quality set to {server.frame_quality}", 200
        except ValueError:
            return "Invalid quality value", 400
    return "OK"

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='0.0.0.0')
    parser.add_argument('--port', type=int, default=5566)
    parser.add_argument('--min', type=int, default=1)
    parser.add_argument('--max', type=int, default=4)
    args = parser.parse_args()
    
    server = EnhancedStreamServer(
        host=args.host,
        port=args.port,
        min_clients=args.min,
        max_clients=args.max
    )
    try:
        server.start()
    except KeyboardInterrupt:
        server.stop()