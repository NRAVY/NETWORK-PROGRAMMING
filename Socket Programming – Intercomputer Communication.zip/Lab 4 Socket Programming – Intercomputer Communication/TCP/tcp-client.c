#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    char *ip = "192.168.137.226"; // Corrected missing semicolon
    int port = 5566;

    int sock;
    struct sockaddr_in addr;
    char buffer[1024]; // Declare buffer for communication

    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("[-]Socket error");
        exit(1);
    }
    printf("[+]TCP client socket created.\n");

    // Configure address structure
    memset(&addr, '\0', sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port); // Use htons for port conversion
    addr.sin_addr.s_addr = inet_addr(ip);

    // Connect to the server
    if (connect(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("[-]Connection error");
        exit(1);
    }
    printf("[+]Connected to the server.\n");

    // Code to communicate with the server
    bzero(buffer, sizeof(buffer)); // Clear the buffer
    strcpy(buffer, "Hello, this is the client speaking.");
    printf("Client: %s\n", buffer);
    
    // Send message to the server
    if (send(sock, buffer, strlen(buffer), 0) < 0) {
        perror("[-]Send error");
        close(sock); // Close socket on error
        exit(1);
    }

    bzero(buffer, sizeof(buffer)); // Clear the buffer again

    // Receive message from the server
    if (recv(sock, buffer, sizeof(buffer), 0) < 0) {
        perror("[-]Receive error");
        close(sock); // Close socket on error
        exit(1);
    }
    printf("Server: %s\n", buffer);

    close(sock); // Close the socket
    printf("[+]Client Disconnected....\n\n"); 
    return 0;
}
