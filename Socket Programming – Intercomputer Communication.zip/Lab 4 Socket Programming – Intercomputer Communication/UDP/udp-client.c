#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    char *ip = "192.168.137.226"; // Updated to match the server IP
    int port = 5566;

    int sock;
    struct sockaddr_in addr;
    char buffer[1024]; // Buffer for communication

    // Create UDP socket
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("[-]Socket error");
        exit(1);
    }
    printf("[+]UDP client socket created.\n");

    // Configure server address structure
    memset(&addr, '\0', sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port); // Use htons for port conversion
    addr.sin_addr.s_addr = inet_addr(ip);

    // Indicate connection to server
    printf("[+]Connected to server at %s:%d\n", ip, port);

    // Send message to server
    bzero(buffer, sizeof(buffer)); // Clear the buffer
    strcpy(buffer, "Hello, this is the client speaking.");
    printf("Client: %s\n", buffer);
    
    if (sendto(sock, buffer, strlen(buffer), 0, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("[-]Send error");
        close(sock); // Close socket on error
        exit(1);
    }
    printf("[+]Message sent to server.\n");

    // Receive response from server
    bzero(buffer, sizeof(buffer)); // Clear the buffer again
    socklen_t addr_len = sizeof(addr); // Initialize address length
    if (recvfrom(sock, buffer, sizeof(buffer), 0, (struct sockaddr*)&addr, &addr_len) < 0) {
        perror("[-]Receive error");
        close(sock); // Close socket on error
        exit(1);
    }
    printf("Server: %s\n", buffer); // Print received response

    close(sock); // Close the socket
    printf("[+]Client Disconnected....\n\n");
    return 0;
}
