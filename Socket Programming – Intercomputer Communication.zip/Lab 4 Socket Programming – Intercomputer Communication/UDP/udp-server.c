#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    char *ip = "192.168.8.106"; 
        int port = 5566;

    int sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_size;
    char buffer[1024]; // Buffer for communication

    // Create UDP socket
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("[-]Socket error");
        exit(1);
    }
    printf("[+]UDP server created.\n");

    // Configure server address structure
    memset(&server_addr, '\0', sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port); // Use htons for port
    server_addr.sin_addr.s_addr = inet_addr(ip);

    // Bind the socket
    if (bind(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("[-]Bind error");
        close(sock); // Close socket on error
        exit(1);
    }
    printf("Bind to port number: %d\n", port);
    printf("Server is listening for messages...\n");

    while (1) {
        addr_size = sizeof(client_addr);
        bzero(buffer, sizeof(buffer)); // Clear the buffer

        // Receive message from client
        ssize_t recv_len = recvfrom(sock, buffer, sizeof(buffer), 0, (struct sockaddr*)&client_addr, &addr_size);
        if (recv_len < 0) {
            perror("[-]Receive error");
            continue; // Continue to listen for new messages
        }
        printf("Client: %s\n", buffer); // Print received message

        // Prepare response
        bzero(buffer, sizeof(buffer)); // Clear the buffer again
        strcpy(buffer, "Hi, this is the server speaking, thanks for reaching out....");
        printf("Server: %s\n", buffer); // Print response message

        // Send response to client
        ssize_t sent_len = sendto(sock, buffer, strlen(buffer), 0, (struct sockaddr*)&client_addr, addr_size);
        if (sent_len < 0) {
            perror("[-]Send error");
        } else {
            printf("[+]Response sent to client.\n");
        }
    }

    close(sock); // Close the socket
    return 0;
}
